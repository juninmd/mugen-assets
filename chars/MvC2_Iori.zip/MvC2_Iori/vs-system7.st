; =======================================================================================
; Capcom VS System Common State File.
; The following is a copy, with modifications in the common1.cns
; M.U.G.E.N. System File, to emulate Capcom VS. System Behavior.
; It uses almost the same layout as the original file.

; --------- Credits ---------------------------------------------------------------------
; Thanks to the following people that made this possible:
; - Elecbyte: For the main common template system.
; - Capcom: For making the vs series and allowing using the features.
; - Chankast: For letting me analyze Marvel vs Capcom 2 carefully.
; - REDHOT: For all his help and his MvC2 sparks.
; - Kung Fu Man: For pointing out how many system vars does mugen use.
; - Messastsu: For teaching how to use common files for your chars and some other concepts.
; - MGBenz: For letting me use this template for Felicia and testing.
; - Mauteck: For some MvC2 sparks used.
; - Kung Fu Man: For the new sets of standard animations.
; - Rednavi: Full game coding advices, Lifebar support, full tag features and full AI control.
; - Cyanide: Coding asistance.
; - Vans: Velocity issues in hitstates bugfix.

; =======================================================================================
;                                  Version revision: 7.1
; =======================================================================================
; NOTE: This version will only work on M.U.G.E.N. Engine 1.0 or above. This is a special version
; that works in the engine outside a full game.

; System variables usage
; ----------------------
; Var name    Type   Purpose
; --------    ----   -------
; sysvar(0)   Temp   Used by guarding states.
;                    Used for Wall hit sparks and effects.
; sysvar(1)   Temp   Used by state 40 (Jump Start) amd 45 (Air Jump Start)
;                    to keep track of which way to jump.
;                    Used in guarding states for advancing guard life
;                    control.
;                    Set by state 5071-81 (HITL_SLIDE & HIT_TRIP) to 1
;                    to prevent showing ground hit frame in state 5110
;                    (HIT_LIEDOWN).
; sysvar(2)   Free
; sysvar(3)   Free
; sysvar(4)   Temp   Recovery Roll var, used for generic recovery roll.

; System float variables usage
; ----------------------------
; Var name    Type   Purpose
; --------    ----   -------
; SysFVar(0)  Temp   Used by state 5100 and 5110 to remember downward
;                    velocity of player just before hitting the ground.
; SysFVar(1)  Free
; SysFVar(2)  Free
; SysFVar(3)  Free
; SysFVar(4)  Free

;-----------------------------------------------------------------------
; The following states have special handling within MUGEN, and should be
; overridden with caution:
; Jump Start (40):            airjumping bookkeeping at time = 0
; All guard states (120-155): guard handling throughout state
; Hit_trip, shaking (5070):   defence increases at time = 0
; Hit_bounce (5100):          defence increases at time = 0, player becomes
;                             invincible if within 10 ticks of getting up
; Hit_liedown (5110):         player changes to state 5111 inmediately to avoid
;                             the button mashing getup (M.U.G.E.N. old behavior)
; Hit_liedown2 (5111):        lie down state, after 15 ticks player changes into
;                             get up state (5120).
; Hit_getup (5120):           player's defence is restored to normal at time = 0

; --- The folowing are present just to maintain compatibility with other
;     chars.
; Hit_up_t (5035):            hit up transition (redirects to 5050 now)
; Hitfall_recover (5200):     player's defence is restored at time = 0
; Hitfall_airrecover (5210):  player's defence is restored at time = 0

; =======================================================================================

; Changelog
; ----------
; 08/11/2012
; - Replaced deprecated HitVelSet sctrls in many hitstates with VelSet ones
;   using GetHitVar trigger to get apropiate velocity parameters from hitdefs.
; - Aplied Van's fix for double acceleration apliance issues in hitstates.

; 30/08/2012
; - Reworked State 10, and Dashing states to enable a wave dash system closer
;   to MvC2 and vs games.
; - Reworked code for Aerial Gethit states, now the use of the hitdef
;   parameters is more precise to what you want to do, GetHitVar(HitTime) and
;   other parameters now emulate the behaviour closer to VS system handling.
;   If HitFall flag is set, you cannot recover in air nor ground, and you only
;   can do a recovery roll if CanRecover flag allows you to do so. If not
;   falling, you can recover either in air or ground automatically.
;   Fall.recovertime parameter in hitdefs now modifies liedown times.
;   All this changes removes the need for custom states during some Flying
;   Screen moves and Aerial Rave finishers in full game enviornments.
; - Changed some gethit animations to match current system behaviour. Added new
;   standards: 50160, 50161, 50162.
; - Replaced triggers in which fall parameters were used for knock back attacks
;   this in concecuence changed the way recoveries are handled, so now, for
;   attacks that should not make the opponent fall the forcenofall parameter
;   in hitdefs is mandatory, otherwise, extrange behaviours shoud occur.
; - Upgraded majority of states to reflect the new system changes
; - Replaced some old standard states with new ones.
; - State 5900 now handles turns mode special intros.
; - Fixed issues regarding Advancing Guard feature.

; 20/02/2010:
; - Upgraded to M.U.G.E.N. 1.0 Standards.
; - Fixed some issues with GetHitVar(HitTime) trigger in state 5030
; - Updated most velocity and position controls using const720p trigger.
; - Updated Master System Helper to match 1.0 Standards, such as using
;   the AILevel trigger instead of the old AI var for detecting AI.
; - Fixed debug flood when Master System Helper was not in Tag mode.
; - Many changes to state controllers so they are compatible with Tag
;   System file.

; 14/08/2009:
; - Fixed some issues with certain states
; - Fixed Advanced Guard code, now behaves more like MvC2

; 28/08/2008:
; - Added a new set of required sprites and animations, they are 5250
;   and 5251 (HIT_UP Spining vertical type, thanks to Kung Fu Man)
; - Fixed some issues with combo counter and delayed hyper combos.

; 15/07/2008:
; - Cleaned Up auto recovery in ground states (5101, 5102), removed
;   unnecesary state 5103.
; - Fixed Facing problems in Get Hit states (hitdefs now don't
;   require the p2facing paramenter by default, unless you need to
;   overrride this in any move)

; 20/06/2008:
; - Fixed some issues with state 5050 changing animations too fast.
; - Fixed some issues with Hyper BG and Hyper Combo Finish Helpers.
;   For the fixes to be aplied correctly, now they are separated for
;   better results.
; - Fixed some behaviors in states 5101 and 5103, now they are close
;   to vs-system behavior.
; - Updated Hyper BG Helper to make it compatible with Delayed Hyper
;   Combo System (comes from vs-tagsys.st, contained on every char)
; - Corrected some constant velocities in HIT_L states, they aren't
;   dependant of the hitdefs anymore. (as they are meant to be)

; First Version:
; - Changed behavior in Ground, Crouch and Air GetHit states to match
;   Capcom VS System behavior (not 100% accurate though).
; - Removed original recovery controls for falling states, since this
;   feature is not used in the VS system, now in situations in which
;   you can recover, you will be able to do it automaticaly.
; - Fixed some issues in aerial gethit animations (animation not timed
;   correctly).
; - State 5035 is no longer used, now it redirects to the new VS system
;   states, maintained just for compatibility.
; - Changed behavior in HITL_SHAKE (5080) to emulate VS System behavior
;   when hitting a foe that is lying down (OTG hits). For the sake of
;   emulation, a new state and animation had been added (5082) if 5082
;   is not found, 5110 anim will be displayed instead.
; - Changed behavior in state 5100 to emulate VS system features in
;   ground hits, like bounce and auto recover from ground.
; - Modified state 5110 to avoid button mashing when lying down, now
;   it redirects to a new state (5111) which changes to either 5120
;   when alive or 5150 when you aren't when 15 tick have passed.
; - Added a new common state for Vs series: Recovery Roll, a new
;   animation is required for this one (5190), if not found 5110 anim
;   is displayed. Also is required a new set of commands for this feature,
;   which needs to be present in your char in order to get this working,
;   read the readme file to see how.
; - Coded an animation skipper for certain velocities, so the animations
;   show properly like in VS system.

; Animation setup
; This new system requires the following animations, most of them are
; M.U.G.E.N. default, but with minor changes to emulate Vs System.
; Only changed anims will be listed here, others should be set like if
; you were using standard common1.cns file.
; * 5030  - Hit Diagonal Up anim (used when DiagUp anim is defined or when
;           you die. (Must not exceed 4 ticks of total animation time, use
;           loopstart if necesary)
; * 5035  - Hit Up transition for either DiagUp or Up anims (Must not exceed 4
;           ticks of total animation time, use loopstart in the last frames).
; * 5050  - Hit Up: going down anim (1 frame, 3 or 4 ticks)
; * 5060  - Hit Up going down: (ending falling frames, frames will vary,
;           they should be a total of 5 or 6 tiks for the whole animation
;           a loop should be placed for the last frame(s).
; * 5082  - Roll after HITL_SLIDE (just like MvC recovery roll, but it is
;           executed after HITL_SLIDE automaticaly.
; * 5140  - This animation will be shown now when you die before your
;           partner, the clasic VS vanish animation.
; * 5150  - No changes, except that this one will be shown at the end of
;           the match.
; * 5160  - MUST have infinite looptime.
; * 5190  - Recovery roll animation, Finite looptime, can be rolling or a
;           modification for the get up animation (like Magneto's).
; * 5250  - HIT_UP Vertical Spinning around: This animations are used
;           for some moves, like Jin's M. Typhoon, this one is triggered in
;           state 5060 if GetHitVar(AnimType) = 5 (DiagUp).
; * 5251  - HIT_UP Vertical Spining going down: same as 5251, but going
;           down. This both anims are REQUIRED by the system, otherwise,
;           wrong anim behaviors should occur.
; * 50160 - Advancing Guard Standing: Must have infinite looptime
; * 50161 - Advancing Guard Crouching: Must have infinite looptime
; * 50162 - Advancing Guard Aerial: Must have infinite looptime, all this three
; *         anims are required for advancing guard to work properly.
; The rest can be set like in M.U.G.E.N.'s common1.cns
; *For better results, you must use animations separated, for instance
; 5030, 5035, 5050, 5060 and so on, because the system skips some anims
; depending of the hit received and velocity.

; =======================================================================================


;---------------------------------------------------------------------------

; Normal generic states
; This can be overriden depending of the features you want for your char

;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
; Stand
[Statedef 0]
type = S
physics = S
sprpriority = 0

[State 0, 1]
type = ChangeAnim
trigger1 = Anim != 0 && Anim != 5
trigger2 = Anim = 5 && AnimTime = 0 ;Turn anim over
value = 0

[State 0, 2]
type = VelSet
trigger1 = Time = 0
y = 0

[State 0, 3] ;Stop moving if low velocity or 4 ticks pass
type = VelSet
trigger1 = abs(vel x) < Const(movement.stand.friction.threshold)
trigger2 = Time = 4
x = 0

[State 0, 4] ;Are you dead?
type = ChangeState
trigger1 = !Alive || !Life
value = 5050

[State 0, 5] ;Are you floating?
type = ChangeState
trigger1 = Pos Y != 0
value = 50

;---------------------------------------------------------------------------
; Turning State Standing (VS Turning Fix)
[Statedef 5]
type    = S
physics = S
ctrl = 0
anim = 5

[State 5, 1]
type = Turn
trigger1 = Time = 0

[State 5, 2]
type = CtrlSet
trigger1 = Time = 2
value = 1

[State 5, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
; Turning State Crouching (VS Turning Fix)
[Statedef 6]
type    = C
physics = C
ctrl = 0
anim = 6

[State 6, 1]
type = Turn
trigger1 = Time = 0

[State 6, 2]
type = CtrlSet
trigger1 = Time = 2
value = 1

[State 6, 3]
type = ChangeState
trigger1 = AnimTime = 0
value = 11
ctrl = 1

;---------------------------------------------------------------------------
; Stand to Crouch
[Statedef 10]
type    = C
physics = N
anim = 10

[State 10, 1]
type = VelSet
trigger1 = abs(vel x) < Const(movement.crouch.friction.threshold)
x = 0

[State 10, 2]
type = VelMul
trigger1 = !(PrevStateNo = [100, 106])
x = const(movement.crouch.friction)

[State 10, 3]
type = ChangeState
triggerall = !Ctrl
trigger1 = AILevel = 0 && command != "holddown"
value = 12
ctrl = 1

[State 10, 4]
type = ChangeState
triggerall = !Ctrl
trigger1 = AILevel = 0 && (command = "holdback" && InGuardDist)
value = 120

[State 10, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 11
ctrl = 1

;---------------------------------------------------------------------------
; Crouching
[Statedef 11]
type    = C
physics = C
anim = 11
sprpriority = 0

[State 11, 1] ;Change from turning animation
type = ChangeAnim
trigger1 = Anim = 6 && AnimTime = 0
value = 11

[State 11, 2] ;Stop moving if low velocity
type = VelSet
trigger1 = abs(vel x) < Const(movement.crouch.friction.threshold)
x = 0

;---------------------------------------------------------------------------
; Crouch to Stand
[Statedef 12]
type    = S
physics = S
anim = 12

[State 12, 1]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
; Walk
[Statedef 20]
type    = S
physics = S
sprpriority = 0

[State 20, 2]
type = VelSet
trigger1 = AILevel = 0 && command = "holdfwd"
x = const(velocity.walk.fwd.x)

[State 20, 3]
type = VelSet
trigger1 = AILevel = 0 && command = "holdback"
x = const(velocity.walk.back.x)

[State 20, 4]
type = ChangeAnim
triggerall = vel x > 0
trigger1 = Anim != 20 && Anim != 5
trigger2 = Anim = 5 && AnimTime = 0
value = 20

[State 20, 5]
type = ChangeAnim
triggerall = vel x < 0
trigger1 = Anim != 21 && Anim != 5
trigger2 = Anim = 5 && AnimTime = 0
value = 21

;---------------------------------------------------------------------------
; Jump / Super Jump start
[Statedef 40]
type    = S
physics = S
anim = 40
ctrl = 0
sprpriority = 1

[State 40, 2]
type = VarSet
trigger1 = Time = 0
sysvar(1) = 0

[State 40, 3]
type = VarSet
trigger1 = AILevel = 0 && command = "holdfwd"
sysvar(1) = 1

[State 40, 4]
type = VarSet
trigger1 = AILevel = 0 && command = "holdback"
sysvar(1) = -1

[State 40, 5]
type = VelSet
trigger1 = AnimTime = 0
x = cond(sysvar(1) = 0, const(velocity.jump.neu.x), cond(sysvar(1) = 1, const(velocity.jump.fwd.x), const(velocity.jump.back.x)))
y = const(velocity.jump.y)

[State 40, 6]
type = VelSet
trigger1 = (AnimTime = 0) && (prevstateno = 100) && (sysvar(1) = 1)
x = const(velocity.runjump.fwd.x)

[State 40, 7]
type = ChangeState
trigger1 = cond(var(33), time = 3, AnimTime = 0)
value = 50
ctrl = 1

;---------------------------------------------------------------------------
; AirJump Start
[Statedef 45]
type    = A
physics = N
ctrl = 0
velset = 0,0

[State 45, 2]
type = VarSet
trigger1 = Time = 0
sysvar(1) = 0

[State 45, 3]
type = VarSet
trigger1 = AILevel = 0 && command = "holdfwd"
sysvar(1) = 1

[State 45, 4]
type = VarSet
trigger1 = AILevel = 0 && command = "holdback"
sysvar(1) = -1

[State 45, 5]
type = VelSet
trigger1 = Time = 2
x = cond(sysvar(1) = 0, const(velocity.airjump.neu.x), cond(sysvar(1) = 1, const(velocity.airjump.fwd.x), const(velocity.airjump.back.x)))
y = const(velocity.airjump.y)

[State 45, 6]
type = ChangeState
trigger1 = Time = 2
value = 50
ctrl = 1

;---------------------------------------------------------------------------
; Jump / Super Jump Up
[Statedef 50]
type    = A
physics = A

[State 50, 1]
type = VarSet
trigger1 = Time = 0
sysvar(1) = 0

[State 50, 2] ;Change to going up anim normally
type = ChangeAnim
trigger1 = Time = 0
value = cond((vel x) = 0, 41, cond((vel x) > 0, 42, 43))

[State 50, 3a] ;Then to going down anim
type = ChangeAnim
trigger1 = AnimTime = 0
trigger1 = SelfAnimExist(anim + 3)
persistent = 0
value = Anim + 3

;---------------------------------------------------------------------------
; Jump Down (empty state for compatibility)
[Statedef 51]
type    = A
physics = A

[State 51, 1]
type = Null
trigger1 = 1

;---------------------------------------------------------------------------
; Jump Land
[Statedef 52]
type    = S
physics = S
ctrl = 0
anim = 47

[State 52, 1]
type = VelSet
trigger1 = Time = 0
x = 0
y = 0

[State 52, 2]
type = PosSet
trigger1 = Time = 0
y = 0

[State 52, 3]
type = ChangeState
trigger1 = (P2Dist X < Const720p(-20)) && (Time = 1)
value = 5 + (StateType = C)

[State 52, 4]
type = CtrlSet
trigger1 = Time = 3
value = 1

[State 52, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;-------------------------------------------------------------------
; Dash Foward
[Statedef 100]
type    = U ;Original Capcom Value, normal should be S
movetype = I
physics = N
anim = 100
ctrl = 0
sprpriority = 1

[State 100, 1]
type = VelSet
trigger1 = Time = 0
x = const(velocity.run.fwd.x)

; Due to Statetype bug in vs games, you obviously
; cannot crouch if your state is already crouch.
[State 1xx, Crouch]
type = ChangeState
triggerall = StateType = S
trigger1 = AILevel = 0 && command = "holddown"
value = 10

[State 1xx, Jump]
type = ChangeState
triggerall = !var(33)
trigger1 = AILevel = 0 && command = "holdup"
value = 40

[State 1xx, Guard]
type = ChangeState
trigger1 = AILevel = 0 && (command = "holdback" && InGuardDist)
value = 120

 ;Capcom has a bug in their dash states in vs games, this
; is added to emulate that bug...
[State 1xx, DSH-BUG.n] ;This thing makes possible to wavedash ala mvc2
type = StateTypeSet
triggerall = StateType = C
trigger1 = AILevel = 0 && command != "holddown"
statetype = S

[State 100, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 101

;-------------------------------------------------------------------
; Dash Foward (stop)
[Statedef 101]
type    = U ;Original Capcom Value, normal should be S
movetype = I
physics = S
ctrl = 0
anim = 12

[State 106, 1]
type = VelSet
trigger1 = abs(vel x) < Const(movement.stand.friction.threshold)
x = 0

[State 101, 2]
type = VelSet
trigger1 = Time = 0
y = 0

[State 101, 3]
type = PosSet
trigger1 = Time = 0
y = 0

; Due to Statetype bug in vs games, you obviously
; cannot crouch if your state is already crouch.
[State 1xx, Crouch]
type = ChangeState
triggerall = StateType = S
trigger1 = AILevel = 0 && command = "holddown"
value = 10

[State 1xx, Jump]
type = ChangeState
triggerall = !var(33)
trigger1 = AILevel = 0 && command = "holdup"
value = 40

[State 1xx, Guard]
type = ChangeState
trigger1 = AILevel = 0 && (command = "holdback" && InGuardDist)
value = 120

 ;Capcom has a bug in their dash states in vs games, this
; is added to emulate that bug...
[State 1xx, DSH-BUG.n] ;This thing makes possible to wavedash ala mvc2
type = StateTypeSet
triggerall = StateType = C
trigger1 = AILevel = 0 && command != "holddown"
statetype = S

[State 101, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
; Dash Back
[Statedef 105]
type    = U ;Original Capcom Value, normal should be S
movetype = I
physics = N
ctrl = 0
anim = 105
sprpriority = 1

[State 105, 1]
type = VelSet
trigger1 = Time = 0
x = const(velocity.run.back.x)

; Due to Statetype bug in vs games, you obviously
; cannot crouch if your state is already crouch.
[State 1xx, Crouch]
type = ChangeState
triggerall = StateType = S
trigger1 = AILevel = 0 && command = "holddown"
value = 10

[State 1xx, Jump]
type = ChangeState
triggerall = !var(33)
trigger1 = AILevel = 0 && command = "holdup"
value = 40

[State 1xx, Guard]
type = ChangeState
trigger1 = AILevel = 0 && (command = "holdback" && InGuardDist)
value = 120

 ;Capcom has a bug in their dash states in vs games, this
; is added to emulate that bug...
[State 1xx, DSH-BUG.n] ;This thing makes possible to wavedash ala mvc2
type = StateTypeSet
triggerall = StateType = C
trigger1 = AILevel = 0 && command != "holddown"
statetype = S

[State 105, 2]
type = ChangeState
trigger1 = AnimTime = 0
value = 106

;---------------------------------------------------------------------------
; Dash Back (stop)
[Statedef 106]
type    = U ;Original Capcom Value, normal should be S
movetype = I
physics = S
ctrl = 0
anim = 12

[State 106, 1]
type = VelSet
trigger1 = abs(vel x) < Const(movement.stand.friction.threshold)
x = 0

[State 106, 2]
type = VelSet
trigger1 = Time = 0
y = 0

[State 106, 3]
type = PosSet
trigger1 = Time = 0
y = 0

; Due to Statetype bug in vs games, you obviously
; cannot crouch if your state is already crouch.
[State 1xx, Crouch]
type = ChangeState
triggerall = StateType = S
trigger1 = AILevel = 0 && command = "holddown"
value = 10

[State 1xx, Jump]
type = ChangeState
triggerall = !var(33)
trigger1 = AILevel = 0 && command = "holdup"
value = 40

[State 1xx, Guard]
type = ChangeState
trigger1 = AILevel = 0 && (command = "holdback" && InGuardDist)
value = 120

 ;Capcom has a bug in their dash states in vs games, this
; is added to emulate that bug...
[State 1xx, DSH-BUG.n] ;This thing makes possible to wavedash ala mvc2
type = StateTypeSet
triggerall = StateType = C
trigger1 = AILevel = 0 && command != "holddown"
statetype = S

[State 106, 4]
type = ChangeState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
;
; Guard generic states
; This can be overriden depending of the features you want for your char
;
;---------------------------------------------------------------------------

;---------------------------------------------------------------------------
; GUARD (start)
[Statedef 120]
type = U    ;Leave state type unchanged
physics = U ;Leave physics unchanged

[State 120, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 120 + (statetype = C) + (statetype = A)*2

[State 120, 2]
type = StateTypeSet
trigger1 = Time = 0 && statetype = S
physics = S

[State 120, 3]
type = StateTypeSet
trigger1 = Time = 0 && statetype = C
physics = C

[State 120, 4]
type = StateTypeSet
trigger1 = Time = 0 && statetype = A
physics = A

[State 120, Hi to Lo]
type = StateTypeSet
trigger1 = statetype = S && command = "holddown"
statetype = C
physics = C

[State 120, Lo to Hi]
type = StateTypeSet
trigger1 = statetype = C && command != "holddown"
statetype = S
physics = S

[State 120, 5]
type = ChangeState
trigger1 = AnimTime = 0
value = 130 + (statetype = C) + (statetype = A)*2

[State 120, Stop Guarding]
type = ChangeState
trigger1 = command != "holdback"
trigger2 = !inguarddist
value = 140

;---------------------------------------------------------------------------
; Stand guard (guarding)
[Statedef 130]
type    = S
physics = S

[State 130, 1]
type = ChangeAnim
trigger1 = Anim != 130
value = 130

[State 130, Hi to Lo]
type = ChangeState
trigger1 = command = "holddown"
value = 131

[State 130, Stop Guarding]
type = ChangeState
trigger1 = command != "holdback"
trigger2 = !inguarddist
value = 140

;---------------------------------------------------------------------------
; Crouch guard (guarding)
[Statedef 131]
type    = C
physics = C

[State 131, 1]
type = ChangeAnim
trigger1 = Anim != 131
value = 131

[State 131, Lo to Hi]
type = ChangeState
trigger1 = command != "holddown"
value = 130

[State 131, Stop Guarding]
type = ChangeState
trigger1 = command != "holdback"
trigger2 = !inguarddist
value = 140

;---------------------------------------------------------------------------
; Air guard (guarding)
[Statedef 132]
type    = A
physics = N

[State 132, 1]
type = ChangeAnim
trigger1 = Anim != 132
value = 132

[State 132, 2]
type = VelAdd
trigger1 = 1
y = Const(movement.yaccel)

[State 132, 3]
type = VarSet
trigger1 = 1
sysvar(0) = (pos y >= 0) && (vel y > 0)

[State 132, 4]
type = VelSet
trigger1 = sysvar(0)
y = 0

[State 132, 5]
type = PosSet
trigger1 = sysvar(0)
y = 0

[State 132, 6]
type = ChangeState
trigger1 = sysvar(0)
trigger1 = command = "holdback"
trigger1 = inguarddist
value = 130

[State 132, 7]
type = ChangeState
trigger1 = sysvar(0)
value = 52

[State 132, Stop Guarding]
type = ChangeState
trigger1 = command != "holdback"
trigger2 = !inguarddist
value = 140

;---------------------------------------------------------------------------
; Guard (end)
[Statedef 140]
type = U    ;Leave state type unchanged
physics = U ;Leave physics unchanged
ctrl = 1

[State 140, 1]
type = ChangeAnim
trigger1 = Time = 0
value = 140 + (statetype = C) + (statetype = A)*2

[State 140, 2]
type = StateTypeSet
trigger1 = Time = 0 && statetype = S
physics = S

[State 140, 3]
type = StateTypeSet
trigger1 = Time = 0 && statetype = C
physics = C

[State 140, 4]
type = StateTypeSet
trigger1 = Time = 0 && statetype = A
physics = A

[State 140, Hi to Lo]
type = StateTypeSet
trigger1 = statetype = S && command = "holddown"
statetype = C
physics = C

[State 140, Lo to Hi]
type = StateTypeSet
trigger1 = statetype = C && command != "holddown"
statetype = S
physics = S

;[State 140, 5] ;Implemented within engine
;type = ChangeState
;trigger1 = AnimTime = 0
;value = (statetype = C)*11 + (statetype = A)*51

;---------------------------------------------------------------------------
; Stand guard hit (shaking)
[Statedef 150]
type    = S
movetype= H
physics = N
velset = 0,0

[State 150, 1]
type = ChangeAnim
trigger1 = 1
value = 150

[State 150, 2]
type = ChangeState
trigger1 = HitShakeOver
value = 151 + 2*(command = "holddown")

[State 150, Hi to Lo]
type = StateTypeSet
trigger1 = statetype = S && command = "holddown"
statetype = C
physics = C

[State 150, Lo to Hi]
type = StateTypeSet
trigger1 = statetype = C && command != "holddown"
statetype = S
physics = S

[State 150, 3]
type = ForceFeedback
trigger1 = time = 0
waveform = square
time = 3

;---------------------------------------------------------------------------
; Stand guard hit (knocked back)
[Statedef 151]
type    = S
movetype= H
physics = S
anim = 150

;[State 151, 2] ;Deprecated, replaced with VelSet
;type = HitVelSet
;triggerall = !NumHelper(50000)
;trigger1 = Time = 0
;x = 1

[State 151, 2]
type = VelSet
triggerall = !NumHelper(50000)
trigger1 = Time = 0
x = GetHitVar(xvel) * facing

[State 151, 2]
type = VelSet
trigger1 = Time = GetHitVar(slidetime)
trigger2 = HitOver
x = 0

[State 151, 3]
type = CtrlSet
trigger1 = Time = GetHitVar(ctrltime)
value = 1

[State 151, Hi to Lo]
type = StateTypeSet
trigger1 = statetype = S && command = "holddown"
statetype = C
physics = C

[State 151, Lo to Hi]
type = StateTypeSet
trigger1 = statetype = C && command != "holddown"
statetype = S
physics = S

[State 151, 4]
type = ChangeState
trigger1 = HitOver
value = 130
ctrl = 1

;---------------------------------------------------------------------------
; Crouch guard hit (shaking)
[Statedef 152]
type    = C
movetype= H
physics = N
velset = 0,0

[State 152, 1]
type = ChangeAnim
trigger1 = 1
value = 151

[State 152, 3]
type = ChangeState
trigger1 = HitShakeOver
value = 151 + 2*(command = "holddown")

[State 152, Hi to Lo]
type = StateTypeSet
trigger1 = statetype = S && command = "holddown"
statetype = C
physics = C

[State 152, Lo to Hi]
type = StateTypeSet
trigger1 = statetype = C && command != "holddown"
statetype = S
physics = S

[State 152, 4]
type = ForceFeedback
trigger1 = time = 0
waveform = square
time = 4

;---------------------------------------------------------------------------
; Crouch guard hit (knocked back)
[Statedef 153]
type    = C
movetype= H
physics = C
anim = 151

;[State 153, 1] ;Deprecated, replaced with VelSet
;type = HitVelSet
;triggerall = !NumHelper(50000)
;trigger1 = Time = 0
;x = 1

[State 153, 1]
type = VelSet
triggerall = !NumHelper(50000)
trigger1 = Time = 0
x = GetHitVar(xvel) * facing

[State 153, 2]
type = VelSet
trigger1 = Time = GetHitVar(slidetime)
trigger2 = HitOver
x = 0

[State 153, 3]
type = CtrlSet
trigger1 = Time = GetHitVar(ctrltime)
value = 1

[State 153, Hi to Lo]
type = StateTypeSet
trigger1 = statetype = S && command = "holddown"
statetype = C
physics = C

[State 153, Lo to Hi]
type = StateTypeSet
trigger1 = statetype = C && command != "holddown"
statetype = S
physics = S

[State 153, 4]
type = ChangeState
trigger1 = HitOver
value = 131
ctrl = 1

;---------------------------------------------------------------------------
; Air guard hit (shaking)
[Statedef 154]
type    = A
movetype= H
physics = N
velset = 0,0

[State 154, 1]
type = ChangeAnim
trigger1 = 1
value = 152

[State 154, 2]
type = ChangeState
trigger1 = HitShakeOver
value = 155 ;AGUARDHIT2

[State 154, 3]
type = ForceFeedback
trigger1 = time = 0
waveform = square
time = 4

;---------------------------------------------------------------------------
; Air guard hit (knocked away)
[Statedef 155]
type    = A
movetype= H
physics = N
anim = 152

;[State 155, 1] ;Deprecated, replaced with VelSet
;type = HitVelSet
;trigger1 = Time = 0
;x = 1
;y = 1

[State 155, 1]
type = VelSet
trigger1 = Time = 0
x = GetHitVar(xvel) * facing
y = GetHitVar(yvel)

[State 155, 2]
type = VelAdd
trigger1 = 1
y = Const(movement.yaccel)

[State 155, 3]
type = CtrlSet
trigger1 = Time = GetHitVar(ctrltime)
value = 1

[State 155, 4]
type = VarSet
trigger1 = 1
sysvar(0) = (pos y >= 0) && (vel y > 0)

[State 155, 5]
type = VelSet
trigger1 = sysvar(0)
y = 0

[State 155, 6]
type = PosSet
trigger1 = sysvar(0)
y = 0

[State 155, 6]
type = ChangeState
trigger1 = sysvar(0)
trigger1 = command = "holdback"
trigger1 = inguarddist
value = 130

[State 155, 7]
type = ChangeState
trigger1 = sysvar(0)
value = 52

;---------------------------------------------------------------------------
;
; Generic Lose, Intros and Win states
; This can be overriden depending of the features you want for your char
;
;---------------------------------------------------------------------------

;---------------------------------------------------------------------------
; Lose by Time Over
[Statedef 170]
type = S

[State 170, ERTX-22]
type = Null
trigger1 = 1

;---------------------------------------------------------------------------
; Draw game (time over)
[Statedef 175]
type = S
ctrl = 0
velset = 0,0

[State 175, 1] ; If no anim, use go to lose state.
type = ChangeState
trigger1 = Time = 0
trigger1 = !SelfAnimExist(175)
value = 170

[State 175, 2]
type = ChangeAnim
trigger1 = Time = 0
value = 175

[State 175, 3]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

;---------------------------------------------------------------------------
; Win state decider
[Statedef 180]
type = S

[State 180, ERTX-22]
type = Null
trigger1 = 1

;---------------------------------------------------------------------------
; Pre-intro (Not Used)
[Statedef 190]
type = S
ctrl = 0
velset = 0,0

[State 190, ERTX-22]
type = Null
trigger1 = 1

;---------------------------------------------------------------------------
;
; Vs System GetHit States
;
;---------------------------------------------------------------------------

;---------------------------------------------------------------------------
; Stand get-hit (shaking)
[Statedef 5000]
type    = S
movetype= H
physics = N
velset = 0,0
facep2 = 1

[State SYS-Fix, RP]
type = VarSet
trigger1 = Time = 0
sysvar(1) = 0

[State 5000, PR-FIX]
type = PosSet
trigger1 = time = 0
y = 0

[State 5000, 1x]
type = ChangeState
triggerall = HitShakeOver
trigger1 = !Alive || !Life
value = 5090

[State 5xxx, GetHit Anim (Normal to Launched)]
type = ChangeAnim
trigger1 = Time = 0
value = (5000 + ((GetHitVar(GroundType) = 2) * 10)) + (GetHitVar(AnimType) - (3 * (GetHitVar(AnimType) = [3,5])))

[State 5000, 2] ;Freeze anim
type = ChangeAnim
trigger1 = Time > 0
value = Anim

[State 5000, FFB Light]
type = ForceFeedback
trigger1 = anim = 5000
trigger2 = anim = 5010
persistent = 0
time = 6
waveform = square

[State 5000, FFB Medium]
type = ForceFeedback
trigger1 = anim = 5001
trigger2 = anim = 5011
persistent = 0
time = 8
waveform = sinesquare
ampl = 110,-1,-.3

[State 5000, FFB Hard]
type = ForceFeedback
trigger1 = anim = 5012
trigger2 = anim = 5002
trigger3 = anim = 5030
trigger4 = anim = 5250
persistent = 0
time = 15
waveform = sinesquare
ampl = 140

[State 5000, 3]
type = ChangeState
trigger1 = HitShakeOver
trigger1 = GetHitVar(yvel) = 0 && !GetHitVar(fall)
value = 5001

[State 5000, 4]
type = ChangeState
trigger1 = HitShakeOver
value = 5030

;---------------------------------------------------------------------------
; Stand get-hit (knocked back)
[Statedef 5001]
type    = S
movetype= H
physics = S

;[State 5001, 1] ;Deprecated, replaced with VelSet
;type = HitVelSet
;trigger1 = Time = 0
;x = 1

[State 5001, 1]
type = VelSet
trigger1 = Time = 0
x = GetHitVar(xvel) * facing

[State 5xxx, 2]
type = ChangeAnim
trigger1 = AnimTime = 0
value = (5005 + ((GetHitVar(GroundType) = 2) * 10)) + (GetHitVar(AnimType) - (3 * (GetHitVar(AnimType) = [3,5])))

[State 5001, 3] ;Stop sliding back
type = VelMul
trigger1 = Time >= GetHitVar(slidetime)
x = .6

[State 5001, 4]
type = VelSet
trigger1 = HitOver
x = 0

[State 5001, 5]
type = DefenceMulSet
trigger1 = HitOver
value = 1

[State 5001, 6]
type = SelfState
trigger1 = HitOver
value = 0
ctrl = 1

;---------------------------------------------------------------------------
; Crouch get-hit (shaking)
[Statedef 5010]
type    = C
movetype= H
physics = N
velset = 0,0
facep2 = 1

[State SYS-Fix, RP]
type = VarSet
trigger1 = Time = 0
sysvar(1) = 0

[State 5000, PR-FIX]
type = PosSet
trigger1 = time = 0
y = 0

[State 5010, 1x]
type = ChangeState
triggerall = HitShakeOver
trigger1 = !Alive || !Life
value = 5090

[State 5xxx, GetHit Anim (Normal to Launched)]
type = ChangeAnim
trigger1 = Time = 0
value = 5020 + (GetHitVar(AnimType) - (3 * (GetHitVar(AnimType) = [3,5])))

[State 5010, 2] ;Freeze anim
type = ChangeAnim
trigger1 = Time > 0
value = Anim

[State 5010, FFB Light]
type = ForceFeedback
trigger1 = anim = 5020
persistent = 0
time = 6
waveform = square

[State 5010, FFB Medium]
type = ForceFeedback
trigger1 = anim = 5021
persistent = 0
time = 8
waveform = sinesquare
ampl = 110,-1,-.3

[State 5010, FFB Hard]
type = ForceFeedback
trigger1 = anim = 5022
trigger2 = anim = 5250
persistent = 0
time = 15
waveform = sinesquare
ampl = 140

[State 5010, 3]
type = ChangeState
trigger1 = HitShakeOver
trigger1 = GetHitVar(yvel) = 0 && !GetHitVar(fall)
value = 5011

[State 5010, 4]
type = ChangeState
trigger1 = HitShakeOver
value = 5030

;---------------------------------------------------------------------------
; Crouch get-hit (knocked back)
[Statedef 5011]
type    = C
movetype= H
physics = C

;[State 5011, 1] ;Deprecated, replaced with VelSet
;type = HitVelSet
;trigger1 = Time = 0
;x = 1

[State 5011, 1]
type = VelSet
trigger1 = Time = 0
x = GetHitVar(xvel) * facing

[State 5xxx, 2]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 5025 + (GetHitVar(AnimType) - (3 * (GetHitVar(AnimType) = [3,5])))

[State 5011, 3] ;Stop sliding back
type = VelMul
trigger1 = Time >= GetHitVar(slidetime)
x = .6

[State 5011, 4]
type = VelSet
trigger1 = HitOver
x = 0

[State 5011, 5]
type = DefenceMulSet
trigger1 = HitOver
value = 1

[State 5011, 6]
type = SelfState
trigger1 = HitOver
value = 11
ctrl = 1

;---------------------------------------------------------------------------
; Air get-hit (shaking)
[Statedef 5020]
type    = A
movetype= H
physics = N
velset = 0,0
facep2 = 1

[State SYS-Fix, RP]
type = VarSet
trigger1 = Time = 0
sysvar(1) = 0

[State 5020, 1x]
type = ChangeState
triggerall = HitShakeOver
trigger1 = !Alive || !Life
value = 5090

[State 5xxx, GetHit Anim (Normal to Launched)]
type = ChangeAnim
trigger1 = Time = 0
value = (5000 + ((GetHitVar(AirType) = 2) * 10)) + (GetHitVar(AnimType) - (3 * (GetHitVar(AnimType) = [3,5])))

[State 5020, 2] ;Freeze anim
type = ChangeAnim
trigger1 = Time > 0
value = Anim

[State 5020, FFB Light]
type = ForceFeedback
trigger1 = anim = 5000
trigger2 = anim = 5010
persistent = 0
time = 6
waveform = square

[State 5020, FFB Medium]
type = ForceFeedback
trigger1 = anim = 5001
trigger2 = anim = 5011
persistent = 0
time = 8
waveform = sinesquare
ampl = 110,-1,-.3

[State 5020, FFB Hard]
type = ForceFeedback
trigger1 = anim = 5012
trigger2 = anim = 5002
trigger3 = anim = 5030
trigger4 = anim = [5051,5059]
persistent = 0
time = 15
waveform = sinesquare
ampl = 140

[State 5020, 5]
type = ChangeState
trigger1 = HitShakeOver
value = 5030

;---------------------------------------------------------------------------
; Air get-hit (knocked away)
[Statedef 5030]
type    = A
movetype= H
physics = N

[State 5030, 1]
type = VelAdd
trigger1 = Time > 0
y = GetHitVar(yaccel)

;[State 5030, 2] ;Deprecated, replaced with VelSet
;type = HitVelSet
;trigger1 = Time = 0
;x = 1
;y = 1

[State 5030, 2]
type = VelSet
trigger1 = Time = 0
x = GetHitVar(xvel) * facing
y = GetHitVar(yvel)

[State 5030, 3]
type = ChangeAnim
triggerall = AnimTime = 0
trigger1 = Anim != [5030,5051]
value = Cond(GetHitVar(AnimType) = 4, Cond(SelfAnimExist(5051), 5051, 5030), 5030)

;-----------------------------------------------------------
;Recovery Roll (Taken from Nobuyuki's Magneto MvC2 code)
[State 5030, Recovery Roll Timer Set]
type = VarSet
triggerall = CanRecover && (Alive && Life)
trigger1 = AILevel = 0 && command = "Recovery Roll"
sysvar(4) = 60

[State 5030, Recovery Roll Counter]
type = VarAdd
trigger1 = sysvar(4) > 0
sysvar(4) = -1
;-----------------------------------------------------------

[State 5030, 4]
type = ChangeAnim
triggerall = SelfAnimExist(5035)
trigger1 = Anim = 5051 && Vel Y > Const720p(8)
trigger2 = Anim = 5030 && AnimTime = 0
value = 5035

[State 5030, 5a]
type = SelfState
triggerall = Alive && Life
trigger1 = !HitFall && HitOver
value = 5040

[State 5030, 5b]
type = ChangeState
trigger1 = ((Anim != [5030,5059]) || !SelfAnimExist(5035) || Anim = 5035) && Vel Y > 0
trigger2 = HitVel Y >= 0
trigger3 = Vel Y > 0 && Pos Y >= Const(movement.air.gethit.groundlevel)
value = 5050

;---------------------------------------------------------------------------
; Air get-hit (transition - Not Used)
[Statedef 5035]
type    = A
movetype= H
physics = N

[State 5035, x1] ;Inmediately change into the correct state
type = ChangeState
trigger1 = 1
value = 5050

;---------------------------------------------------------------------------
; Air recovery
[Statedef 5040]
type    = A
movetype= I
physics = N
anim = 5040
ctrl = 1

[State 5040, 1] ;Just in case there are weird changestates into ths...
type = ChangeState
trigger1 = !Alive
value = 5000 + (10 * (StateType = C)) + (20 * (StateType = A))
ctrl = 0

[State 5040, 2]
type = VelAdd
trigger1 = Time > 0
y = GetHitVar(yaccel)

[State 5040, 3]
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 52 ;Jump land

;---------------------------------------------------------------------------
; Air get-hit (falling)
[Statedef 5050]
type    = A
movetype= H
physics = N

[State 5050, A-RX-FIX]
type = ChangeAnim
triggerall = SelfAnimExist(5050) && (!Alive || !Life)
trigger1 = (Anim = [5030,5035]) && AnimTime = 0
trigger2 = (Anim = [5000,5025]) && AnimTime = 0
trigger3 = (Anim != [5000, 5035]) && Time = 0
value = 5050

[State 5050, 1]
type = ChangeAnim
triggerall = SelfAnimExist(5050) && HitVel Y <= 0
trigger1 = (Anim = [5030,5035]) && AnimTime = 0
trigger2 = (Anim = [5000,5025]) && AnimTime = 0
value = 5050

[State 5050, 2] ;Coming down anim
type = ChangeAnim
triggerall = SelfAnimExist(5060)
trigger1 = Anim = 5050 && AnimTime = 0
trigger2 = HitVel Y > 0 && (Anim != [5050,5060]) && AnimTime = 0
value = 5060

[State 5050, 3] ;Gravity
type = VelAdd
trigger1 = Time > 0
y = GetHitVar(yaccel)

;-----------------------------------------------------------
;Recovery Roll (Taken from Nobuyuki's Magneto MvC2 code)
[State 5050, Recovery Roll Timer Set]
type = VarSet
triggerall = CanRecover && (Alive && Life)
trigger1 = AILevel = 0 && command = "Recovery Roll"
sysvar(4) = 60

[State 5050, Recovery Roll Counter]
type = VarAdd
trigger1 = sysvar(4) > 0
sysvar(4) = -1
;-----------------------------------------------------------

[State 5050, 4a]
type = SelfState
triggerall = Alive && Life
trigger1 = !HitFall && HitOver
value = 5040

[State 5050, 4b]
type = ChangeState
trigger1 = Vel Y > 0 && Pos Y >= Const(movement.air.gethit.groundlevel)
value = 5100 ;Downed get-hit (hit ground from fall)

;---------------------------------------------------------------------------
; Tripped get-hit (shaking)
[Statedef 5070]
type    = A
movetype= H
physics = N
velset = 0,0
facep2 = 1

[State 5070, 1x]
type = ChangeState
triggerall = HitShakeOver
trigger1 = !Alive || !Life
value = 5090

[State 5070, 1]
type = ChangeAnim 
trigger1 = 1
value = 5070

[State 5070, 3]
type = ForceFeedback
trigger1 = time = 0
time = 12
waveform = sinesquare
ampl = 140

[State 5070, 2]
type = ChangeState
trigger1 = HitShakeOver
value = 5071

;---------------------------------------------------------------------------
; Tripped get-hit (knocked away)
[Statedef 5071]
type    = A
movetype= H
physics = N

[State 5071, 1] ;Set HIT_TRIP var
type = VarSet
trigger1 = time = 0
sysvar(1) = 1

;[State 5071, 2] ;Deprecated, replaced with VelSet
;type = HitVelSet
;trigger1 = Time = 0
;x = 1
;y = 1

[State 5071, 2]
type = VelSet
trigger1 = Time = 0
x = GetHitVar(xvel) * facing
y = GetHitVar(yvel)

[State 5071, 3] ;Acceleration
type = VelAdd
trigger1 = Time > 0
y = GetHitVar(yaccel)

;-----------------------------------------------------------
;Recovery Roll (Taken from Nobuyuki's Magneto MvC2 code)
[State 5071, Recovery Roll Timer Set]
type = VarSet
triggerall = CanRecover && (Alive && Life)
trigger1 = AILevel = 0 && command = "Recovery Roll"
sysvar(4) = 60

[State 5071, Recovery Roll Counter]
type = VarAdd
trigger1 = sysvar(4) > 0
sysvar(4) = -1
;-----------------------------------------------------------

[State 5071, 4] ;Hit ground
type = ChangeState
trigger1 = Vel Y > 0 && Pos Y >= Const(movement.air.gethit.trip.groundlevel)
value = 5100

;---------------------------------------------------------------------------
; Off The Ground Get Hit
[Statedef 5080]
type    = L
movetype= H
physics = N
velset = 0,0
facep2 = 1

[State 5080, 1x]
type = ChangeState
triggerall = HitShakeOver
trigger1 = !Alive || !Life
value = 5090

[State 5080, 1]
type = ChangeAnim
trigger1 = time = 0
value = 5080

[State 5080, 2] ;Freeze anim
type = ChangeAnim
trigger1 = Time > 0
value = Anim

[State 5080, 3]
type = ChangeState
trigger1 = HitShakeOver
value = 5081

[State 5080, FFB Medium]
type = ForceFeedback
trigger1 = anim = 5080
persistent = 0
time = 8
waveform = sinesquare
ampl = 110,-1,-.3

;---------------------------------------------------------------------------
; Off The Ground Get Hit (Shaking)
[Statedef 5081]
type    = L
movetype= H
physics = N

[State 5081, 1]
type = ChangeAnim
trigger1 = time = 0
value = cond(selfanimexist(5090), 5090, 5050)

[State 5081, 2]
type = StateTypeSet
trigger1 = Pos Y != 0
statetype = A

;Constant aceleration, not dependant from hitdef parameters
[State 5080, 3]
type = VelAdd
trigger1 = Time > 0
y = Const720p(2.76)

;Custom Velocity statement, not dependant from hitdef parameters
[State 5080, 4]
type = VelSet
trigger1 = Time = 0
x = Const720p(-16)
y = Const720p(-34)

[State 5080, 5a]
type = ChangeState
triggerall = Alive
trigger1 = Pos Y >= 0 && Vel Y >= 0
value = 5082

[State 5080, 5b]
type = ChangeState
triggerall = !Alive
trigger1 = Pos Y >= 0 && Vel Y >= 0
value = 5110

;---------------------------------------------------------------------------
; Off The Ground GetHit (Recovery)
[Statedef 5082]
type    = S
movetype= I
physics = N

[State 5082, 1]
type = NotHitBy
trigger1 = 1
value = SCA
time = 20

[State 5082, 2]
type = PosSet
trigger1 = time = 0
y = 0

[State 5082, 3]
type = ChangeAnim
trigger1 = time = 0
value = Cond(SelfAnimExist(5082), 5082, 5110)

[State 5082, 4]
type = VelSet
trigger1 = Time = 0
x = Const720p(-28)
y = 0

[State 5082, 5]
type = VelSet
trigger1 = Time >= 19
x = 0
y = 0

[State 5082, 6]
type = SelfState
trigger1 = Time >= 20
value = 5120

;---------------------------------------------------------------------------
; Dead Get Hit (initial going up, used when dead, Vs System Type)
[Statedef 5090]
type    = A
movetype= H
physics = N

[State 5090, 1]
type = VelAdd
trigger1 = Time > 0
y = GetHitVar(yaccel)

[State 5090, 2a]
type = VelSet
trigger1 = Time = 0 && Roundstate = 2
x = -(abs(GetHitVar(xvel))+(Const720p(16)*(abs(GetHitVar(xvel)) = 0)))
y = -(abs(GetHitVar(yvel)))

[State 5090, 2b]
type = VelSet
trigger1 = Time = 0 && Roundstate > 2
x = -(abs(GetHitVar(xvel)) + (Const720p(20)))
y = -(abs(GetHitVar(yvel)) + (Const720p(20))*(abs(GetHitVar(yvel) < Const720p(56))))

[State 5090, 3] ;Anim for HIT_BACK/HIT_DIAG_UP
type = ChangeAnim
trigger1 = Vel Y < Const720p(-16)
value = Cond(SelfAnimExist(5035), 5035, 5030)

[State 5090, 4]
type = NotHitBy
trigger1 = Vel Y > Const720p(-8)
value = SCA
time = 700

[State 5090, 4]
type = ChangeState
trigger1 = Vel Y > 0
value = 5050

;---------------------------------------------------------------------------
; Downed get-hit (hit ground from fall)
[Statedef 5100]
type    = L
movetype= H
physics = N

[State 5100, Var]
type = VarSet
trigger1 = Time = 0
SysFVar(0) = Vel Y

[State 5100, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA

[State 5100, EnvShake]
type = FallEnvShake
trigger1 = Time = 0

[State 5100, 2]
type = ChangeAnim
trigger1 = time = 0
value = Cond(HitFall, 5100, 5200)

[State 5100, 4]
type = PosSet
trigger1 = Time = 0
y = 0

[State 5100, 5]
type = VelSet
trigger1 = Time = 0
y = 0

[State 5100, 6]
type = ChangeState
triggerall = Time = 0
trigger1 = HitFall
trigger2 = GetHitVar(groundtype) = 3
trigger3 = !Alive || !Life
value = 5110

[State 5100, 7]
type = HitFallDamage
trigger1 = Time = 3

[State 5100, 8]
type = PosFreeze
trigger1 = 1

[State 5100, 9]
type = ChangeState
trigger1 = Time >= 3
value = 5101

[State 5100, 10]
type = ForceFeedback
trigger1 = Time = 0
waveform = sinesquare
ampl = 128,-3,-.2,.005
time = 20

;---------------------------------------------------------------------------
; Downed get-hit (bounce off ground)
[Statedef 5101]
type    = A
movetype= I
physics = N
ctrl = 0

[State 5101, 1]
type = PosAdd
trigger1 = Time = 1
y = Const(movement.down.bounce.offset.y)

[State 5101, 2] ;Turn if not facing opponent
type = Turn
trigger1 = Time = 0
trigger1 = p2dist X < Const720p(-20)

[State 5101, 3]
type = HitFallVel
trigger1 = Time = 0

[State 5101, 4]
type = VelMul
trigger1 = 1
x = 0.90

[State 5101, 5] ;Acceleration
type = VelAdd
trigger1 = 1
y = Const(movement.down.bounce.yaccel)

[State 5101, 6a]
type = SelfState
trigger1 = time >= 2
trigger1 = (command = "holdback") && inguarddist
value = 120

[State 5101, 6b] ;Instant Recovery Near Ground
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= Const(movement.down.bounce.groundlevel)
value = 5102

;---------------------------------------------------------------------------
; Downed get-hit (vs style hitbounce recovery on ground)
[Statedef 5102]
type    = S
movetype= I
physics = S
anim = 47
velset = 0, 0

[State 5102, 1]
type = PosSet
trigger1 = Time = 0
y = 0

[State 5102, RX2]
type = SelfState
trigger1 = (command = "holdback") && inguarddist
value = 120

[State 5102, 2]
type = SelfState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
; Downed get-hit (lying down)
[Statedef 5110]
type    = L
movetype= H
physics = N

[State 5110, 1]
type = ChangeState
trigger1 = 1
value = 5111

;---------------------------------------------------------------------------
; Downed get-hit (VS Series Type)
[Statedef 5111]
type    = L
movetype= H
physics = N

[State 5110, 1]
type = PosSet
trigger1 = Time = 0
y = 0

[State 5110, 2]
type = VelSet
trigger1 = Time = 0
x = 0
y = 0

[State 5110, EnvShake]
type = FallEnvShake
trigger1 = Time = 0

[State 5110, 3]
type = ChangeAnim
trigger1 = time = 0
value = Cond(sysvar(1) && SelfAnimExist(5101), 5101, 5100)

[State 5110, 6]
type = ChangeAnim
trigger1 = (Anim = [5100, 5101]) && (AnimTime = 0)
value = 5110

[State 5110, 7]
type = HitFallDamage
trigger1 = Time = 0

[State 5110, 8]
type = VarSet
trigger1 = (sysvar(1)) && (!Time)
sysvar(1) = 0

;-----------------------------------------------------------
;Recovery Roll (Taken from Nobuyuki's Magneto MvC2 code)
[State 5110, Recovery Roll Timer Set]
type = VarSet
triggerall = CanRecover && (Alive && Life)
trigger1 = AILevel = 0 && command = "Recovery Roll"
sysvar(4) = 60

[State 5110, Recovery Roll Counter]
type = VarAdd
trigger1 = sysvar(4) > 0
sysvar(4) = -1

[State 5110, Recovery Roll]
type = ChangeState
triggerall = Alive
trigger1 = sysvar(4) > 0
value = 5190
;-----------------------------------------------------------

[State 5110, 9a]
type = SelfState
triggerall = Alive && Life
trigger1 = Time >= 15
value = 5120

[State 5110, 9b]
type = SelfState
triggerall = !Alive || !Life
trigger1 = Anim = 5110
trigger2 = Time >= 15
value = 5150

[State 5110, 10]
type = ForceFeedback
trigger1 = Alive && Life
trigger1 = Time = 0
time = 8
ampl = 240
waveform = sine

[State 5110, 11]
type = ForceFeedback
trigger1 = !Alive || !Life
trigger1 = Time = 0
ampl = 200, 7, -.467
time = 30
waveform = sine

;---------------------------------------------------------------------------
; Downed get-hit (getting up)
[Statedef 5120]
type    = S
movetype= I
physics = N

[State A-T, 2]
type = Turn
triggerall = PrevStateNo = 5190
trigger1 = (!time) && (P2Dist X < Const720p(-20))

[State 5120, 1] ;Get up anim
type = ChangeAnim
trigger1 = time = 0
value = 5120

[State 5120, 2]
type = VarSet
trigger1 = 1
sysvar(4) = 0

[State 5120, 3]
type = VelSet
trigger1 = Time = 0
x = 0

[State 5120, 4]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 5120, 5]
type = HitFallSet
trigger1 = AnimTime = 0
value = 1

[State 5120, 6] ;Can't be thrown right after getting up
type = NotHitBy
trigger1 = AnimTime = 0
value = , NT,ST,HT
time = 12

[State 5120, 7] ;Can't be hit right after getting up (short time)
type = NotHitBy
trigger1 = AnimTime = 0
value2 = SCA
time = 3

[State 5120, 8]
type = SelfState
trigger1 = AnimTime = 0
value = 0
ctrl = 1

;---------------------------------------------------------------------------
; Downed get-hit (lying defeated)
[Statedef 5150]
type    = L
movetype= H
physics = N
sprpriority = -3

; -------- Tag Mode only code -----------
[State 5150, tg1] ;Dead anim 1
type = ChangeAnim
triggerall = Time = 0 && TeamMode = Simul
trigger1 = SelfAnimExist(5140) && RoundState != 3
value = 5140
persistent = 0

[State 5150, tg2] ;Vanish away (Tag mode only)
type = Trans
triggerall = time < 100
trigger1 = anim = 5140
trans = addalpha
alpha = 256 - (time * 4), (time * 4)
; ----------------------------------------

[State 5150, 1] ;Dead anim 2
type = ChangeAnim
triggerall = Time = 0 && SelfAnimExist(5150)
trigger1 = Roundstate = 3
value = 5150
persistent = 0

[State 5150, 1a] ;Switch to 5110 if liedead anims does not exist
type = ChangeAnim
triggerall = Time = 0
trigger1 = !SelfAnimExist(5140 + (10 * roundstate = 3))
value = 5110
persistent = 0

[State 5150, 2] ;Friction
type = VelMul
trigger1 = 1
x = 0.85

[State 5150, 3] ;Friction
type = VelSet
trigger1 = abs(vel x) < Const(movement.down.friction.threshold)
x = 0
persistent = 0

[State 5150, 4]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

;----------------------------------------------------------------------
;Recovery Roll (From Nobuyuki's Magneto MvC2 Ver)
[Statedef 5190]
type = S
movetype = I
physics = N
facep2 = 1

[State 5190, 1]
type = ChangeAnim
trigger1 = time = 0
value = cond(SelfAnimExist(5190), 5190, 5110)

[State 5190, 2]
type = VarSet
trigger1 = 1
sysvar(4) = 0

[State 5190, 3]
type = VelSet
trigger1 = time >= 0
x = Const720p(32)

[State 5190, 4]
type = PosSet
trigger1 = 1
y = 0

[State 5190, 5]
type = NotHitby
trigger1 = 1
value = SCA

[State 5190, 6]
type = PlayerPush
trigger1 = 1
value = 0

[State 5190, 7]
type = VelSet
trigger1 = time = 29
x = 0

[State 5190, 8]
type = SelfState
trigger1 = time = 30
value = 5120

;---------------------------------------------------------------------------
; Air get-hit (fall recovery on ground; still falling)
[Statedef 5200]
type    = A
movetype= I
physics = N
anim = 5200

[State 5200, 1] ;Change anim if done with transition
type = ChangeAnim
trigger1 = Time = 0
value = 5200

[State 5200, 2]
type = VelAdd
trigger1 = Time > 0
y = GetHitVar(yaccel)

[State 5200, 3]
type = SelfState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= Const(movement.air.gethit.groundrecover.groundlevel)
value = 5201

;---------------------------------------------------------------------------
; Air get-hit (fall recovery on ground)
[Statedef 5201]
type    = A
movetype= H
physics = A
anim = 5200

[State 5201, 1] ;Turn if not facing opponent
type = Turn
trigger1 = Time = 0
trigger1 = p2dist X < Const720p(-20)

[State 5201, 2]
type = VelSet
trigger1 = Time = 0
x = Const(velocity.air.gethit.groundrecover.x)
y = Const(velocity.air.gethit.groundrecover.y)

[State 5201, 3]
type = PosSet
trigger1 = Time = 0
y = 0

[State 5201, 4]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1

[State 5201, 5] ;Blink white
type = PalFX
trigger1 = Time = 0
time = 3
add = 128,128,128 ;256,256,256

;---------------------------------------------------------------------------
; Air get-hit (fall recovery in air)
[Statedef 5210]
type    = A
movetype= I
physics = N
anim = 5210
ctrl = 0

[State 5210, 1] ;Blink white
type = PalFX
trigger1 = Time = 0
time = 3
add = 128,128,128

[State 5210, 1]
type = PosFreeze
trigger1 = Time < 4

[State 5210, 2] ;Turn if not facing opponent
type = Turn
trigger1 = Time = 0
trigger1 = p2dist X < Const720p(-80)

[State 5210, 1.0 behavior 1]
type = VelMul
trigger1 = Time = 4
x = Const(velocity.air.gethit.airrecover.mul.x)
y = Const(velocity.air.gethit.airrecover.mul.y)

[State 5210, 1.0 behavior 2]
type = VelAdd
trigger1 = Time = 4
x = Const(velocity.air.gethit.airrecover.add.x)
y = Const(velocity.air.gethit.airrecover.add.y)

[State 5210, 2] ;Go up
type = VelAdd
trigger1 = Time = 4
trigger1 = AILevel = 0 && Command = "holdup"
y = Const(velocity.air.gethit.airrecover.up)

[State 5210, 2] ;Go down
type = VelAdd
trigger1 = Time = 4
trigger1 = AILevel = 0 && Command = "holddown"
y = Const(velocity.air.gethit.airrecover.down)

[State 5210, 2] ;Go fwd
type = VelAdd
trigger1 = Time = 4
trigger1 = AILevel = 0 && Command = "holdfwd"
x = Const(velocity.air.gethit.airrecover.fwd)

[State 5210, 2] ;Go back
type = VelAdd
trigger1 = Time = 4
trigger1 = AILevel = 0 && Command = "holdback"
x = Const(velocity.air.gethit.airrecover.back)

[State 5210, 3]
type = NotHitBy
trigger1 = Time = 0
value = SCA
time = 15

[State 5210, 4]
type = CtrlSet
trigger1 = Time = 20
value = 1

[State 5210, 5]
type = VelAdd
trigger1 = Time >= 4
y = Const(movement.air.gethit.airrecover.yaccel)

[State 5210, 5] ;Land on ground
type = ChangeState
trigger1 = Vel Y > 0
trigger1 = Pos Y >= 0
value = 52 ;Jump land
ctrl = 1

;---------------------------------------------------------------------------
; Continue screen animation
[Statedef 5500]
type = S
ctrl = 0
anim = 5300
velset = 0,0

[State 5500, 1] ;Use continue animation if available
type = ChangeAnim
trigger1 = time = 0
trigger1 = SelfAnimExist(5500)
value = 5500

;---------------------------------------------------------------------------
; Infinite breaker get-hit (shaking)
[Statedef 5600]
type    = U
movetype= H
physics = N
velset = 0,0
facep2 = 1
ctrl = 0

[State SYS-EX, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1
ignorehitpause = 1

[State 5020, 1x]
type = ChangeState
triggerall = HitShakeOver
trigger1 = !Alive || !Life
value = 5090

[State 5xxx, GetHit Anim (Normal to Launched)]
type = ChangeAnim
trigger1 = Time = 0
value = (5000 + ((GetHitVar(AirType) = 2) * 10)) + (GetHitVar(AnimType) - (3 * (GetHitVar(AnimType) = [3,5])))

[State 5020, 2] ;Freeze anim
type = ChangeAnim
trigger1 = Time > 0
value = Anim

[State 5020, FFB Light]
type = ForceFeedback
trigger1 = anim = 5000
trigger2 = anim = 5010
persistent = 0
time = 6
waveform = square

[State 5020, FFB Medium]
type = ForceFeedback
trigger1 = anim = 5001
trigger2 = anim = 5011
persistent = 0
time = 8
waveform = sinesquare
ampl = 110,-1,-.3

[State 5020, FFB Hard]
type = ForceFeedback
trigger1 = anim = 5012
trigger2 = anim = 5002
trigger3 = anim = 5030
trigger4 = anim = [5051,5059]
persistent = 0
time = 15
waveform = sinesquare
ampl = 140

[State 5020, 5]
type = ChangeState
trigger1 = HitShakeOver
value = 5601

;---------------------------------------------------------------------------
; Infinite breaker get-hit (spinning up)
[Statedef 5601]
type    = A
movetype= H
physics = N
ctrl = 0

[State SYS-EX, NotHitBy]
type = NotHitBy
trigger1 = 1
value = SCA
time = 1
ignorehitpause = 1

[State 5030, 1]
type = VelAdd
trigger1 = Time > 0
y = const(movement.yaccel)

[State 5030, 2]
type = VelSet
trigger1 = Time = 0
x = 0
y = -18

[State 5030, 3]
type = ChangeAnim
triggerall = AnimTime = 0
trigger1 = Anim = [5000,5029]
value = 5250

[State 5030, 5a]
type = SelfState
trigger1 = Vel Y >= 0
value = 5040

;---------------------------------------------------------------------------
; Initialize
[Statedef 5900]
type = S

[State 5900, M1.0Fix] ;Change palette
type = RemapPal
trigger1 = 1
source = 1,1
dest = 1,palno

[State 5900, 1]  ;Clear all int variables
type = VarRangeSet
trigger1 = !RoundsExisted
first = 0
last = 58
value = 0

[State 5900, 2]  ;Clear all float variables
type = VarRangeSet
trigger1 = !RoundsExisted
fvalue = 0

;-------------------------------------------
;Start Intros
[State 5901, Turns Intro]
type = ChangeState
triggerall = TeamMode = Turns
trigger1 = Time = 0 && (RoundNo != 1) && (!RoundsExisted)
value = 51999

[State 5901, Normal Intro] ;Intro for round 1
type = ChangeState
trigger1 = Time = 0 && RoundNo = 1
value = 51900

[State 5901, 1] ;No intro for further rounds
type = ChangeState
trigger1 = Time = 0 && RoundNo > 1
value = 0


; =================================================================================== ;
;            Full Game Features Section (DO NOT OVERRIDE unless you know              ;
;            what are you doing. This will add extra features to your                 ;
;            chars. THANKS TO: Messatsu for discovering this.                         ;
; =================================================================================== ;

; ========================================================================
;Main System Helper (Controls full game features, Original Template)
[StateDef 1337000000]
anim = 1337000000
ctrl = 0

[State MS - X, IX]
type = AssertSpecial
trigger1 = 1
flag = noshadow
flag2 = invisible

[State MS - Pos, 01]
type = BindToRoot
trigger1 = 1
facing = (root, facing)
pos = 0, 0

;;;;;;;;;;;;;;; Feature 1: Combo Messages ;;;;;;;;;;;;;;;;
; --------------------------------------------------------
; Original by Ryou Win - Used vars for this feature: 5
; - var(1) *** Special var for First Attack (avoids var reset if intro skipped)
; - var(2) *** Ground Hit Count
; - var(3) *** Aerial Hit Count (buggy)
; - var(4) *** Danger Var
; - var(5) *** PlaceHolder for Counter and Danger vars
[State -4, FA - Initial Value]
type = VarSet
trigger1 = (var(1) != 1) && (roundstate <= 2)
trigger2 = (var(1) = 1) && (roundstate < 2)
var(1) = -1

[State -4, FA - Active]
type = VarSet
trigger1 = (NumExplod(32100)) && (var(1) = -1)
var(1) = 0

[State -4, FA - Done]
type = VarSet
trigger1 = (var(1) = 0) && (roundstate >= 2)
trigger2 = (var(2) = -1) && ((root, NumPartner) && (root, MoveType = H || partner, MoveType = H) && ((root, StateNo != [150, 155]) && (partner, StateNo != [150, 155])))
var(1) = 1
;----------------------------

[State -4, HitCount PlaceHolder]
type = VarSet
trigger1 = var(2) >= 3
trigger2 = (var(2) = -1) && (P2MoveType = H) && (P2StateNo != [150, 155])
var(5) = 1 + (var(2) > 4) + (var(2) > 5) + (var(2) > 7) + (var(2) > 9) + (var(2) > 29) + (var(2) > 49) + (var(2) > 69) - (var(2) = -1)

[State -4, Aerial HitCount PlaceHolder]
type = VarSet
trigger1 = var(3) > 1
var(5) = 10

[State -4, Danger On]
type = VarSet
trigger1 = (var(4) != 1) && (roundstate = 2) && (root, life = [1, (root,LifeMax/4)])
var(9) = 1
;----------------------------

[State -4, FA - Danger Sound]
type = PlaySnd
triggerall = Cond(var(9), 1, ((root, NumPartner) && (root, ID) < (Partner, ID)))
triggerall = !NumExplod(32100)
trigger1 = (var(9)) && (var(4) = 0) && (root, life > 0)
trigger2 = (var(2) = -1) && (P2MoveType = H) && (P2StateNo != [150, 155])
value = 32100, Cond(var(9), 9, 0)
volumescale = 100

[State -4, Combo Sounds]
type = PlaySnd
triggerall = Cond(var(9), 1, ((root, NumPartner) && (root, ID) < (Partner, ID)))
trigger1 = (!NumExplod(32100)) && (var(2) = 0 && var(3) = 0 && var(5) != 0)
value = 32100, Cond(var(5) > 9, 30, Cond(var(9), 9, var(5)))
volumescale = 100

[State -4, Combo Message (left)]
type = Explod
triggerall = Cond(var(9), 1, ((root, NumPartner) && (root, ID) < (Partner, ID)))
triggerall = TeamSide = 1 && !NumExplod(32100)
trigger1 = var(2) = 0 && var(3) = 0 && var(5) != 0
trigger2 = (var(2) = -1) && (P2MoveType = H) && (P2StateNo != [150, 155])
trigger3 = (var(9)) && (var(4) = 0) && (root, life > 0)
anim = 32100 + Cond(var(5) > 9, 30, Cond(var(9), 9, var(5)))
ID = 32100
postype = left
pos = 0, 80
ontop = 1
bindtime = -1
removetime = 60
supermovetime = 60
pausemovetime = 60
scale = 0.5,0.5

[State -4, Combo Message (right)]
type = Explod
triggerall = Cond(var(9), 1, ((root, NumPartner) && (root, ID) < (Partner, ID)))
triggerall = TeamSide = 2 && !NumExplod(32100)
trigger1 = var(2) = 0 && var(3) = 0 && var(5) != 0
trigger2 = (var(2) = -1) && (P2MoveType = H) && (P2StateNo != [150, 155])
trigger3 = (var(9)) && (var(4) = 0) && (root, life > 0)
anim = 32110 + Cond(var(5) > 9, 21, Cond(var(9), 9, var(5)))
ID = 32100
postype = right
pos = -1, 80
ontop = 1
bindtime = -1
removetime = 60
supermovetime = 60
pausemovetime = 60
scale = 0.5,0.5
;----------------------------

[State -4, Main HitCount]
type = VarAdd
trigger1 = (enemynear, time = 1) && (enemynear, HitShakeOver = 0) && (P2MoveType = H) && (P2StateNo != [150, 155])
var(2) = 1 + (var(2) = -1)

[State -4, Main HitCount (Aerial Rave)]
type = VarAdd
triggerall = (root, NumPartner) && ((Root, HitDefAttr = A, NA, SA, HA) || (Partner, HitDefAttr = A, NA, SA, HA))
trigger1 = (enemynear, time = 1) && (enemynear, HitShakeOver = 0) && (P2MoveType = H) && (P2StateNo != [150, 155]) && (P2StateType = A)
var(3) = 1

[State -4, Reset HitCount]
type = VarSet
trigger1 = var(2) != -1 && (p2movetype != H || enemynear, ctrl)
trigger2 = (var(2) = -1) && (root, NumPartner) && (root, MoveType = H || partner, MoveType = H) && ((root, StateNo != [150, 155]) && (partner, StateNo != [150, 155]))
trigger3 = (var(2) = -1) && (P2MoveType = H) && (P2StateNo != [150, 155])
var(2) = 0 - (var(1) = -1)

[State -4, Reset HitCount (Aerial Rave)]
type = VarSet
trigger1 = var(2) != -1 && (p2movetype != H || enemynear, ctrl)
trigger2 = (root, NumPartner) && ((Root, HitDefAttr = SC, NA, SA, HA) || (Partner, HitDefAttr = SC, NA, SA, HA))
trigger2 = (P2MoveType = H) && (P2StateNo != [150, 155])
var(3) = 0

[State -4, Reset PlaceHolder Var]
type = VarSet
triggerall = NumExplod(32100)
trigger1 = (var(2) = 0) || (var(3) = 0) || (roundstate != 2)
var(5) = 0

[State -4, Reset PlaceHolder Var]
type = VarSet
trigger1 = NumExplod(32100) || (root, life > (root, LifeMax/4))
var(9) = 0

[State -4, Danger Indicator]
type = VarSet
trigger1 = var(4) = 1 && roundstate != 2
trigger2 = var(4) = 0 && root, life <= (root,LifeMax/4)
var(4) = (roundstate > 1)

[State -4, Danger Indicator]
type = VarSet
trigger1 = var(4) && Roundstate > 1 && (root,life > (root,LifeMax/4))
var(4) = 0
; --------------------------------------------------------

;;;;;;;;;;;;; Feature 2: K.O. for Simul Mode ;;;;;;;;;;;;;;
; --------------------------------------------------------
; Used vars for this feature: 1
; - var(6) *** Detects whenever root or partner had been defeated in roundstate 2 when in simul mode.
[State -4, VarSet]
type = VarSet
trigger1 = (var(6) = 0) && !(root, Alive) && RoundState = 2
var(6) = 1

[State -4, Special K.O. Effect if defeated in simul mode (roundstate = 2)]
type = Helper
triggerall = !NumHelper(1338000000)
trigger1 = var(6) = 1
name = "Finish!"
ID = 1338000000
stateno = 1338000000
persistent = 0

[State -4, VarSet]
type = VarSet
trigger1 = var(6) > 0
trigger2 = (var(6) = 0) && !(Partner, Alive)
var(6) = -1

[State -4, IN-1]
type = VarSet
triggerall = var(6) < 0
trigger1 = Root, StateNo = 5120
var(6) = -1
; --------------------------------------------------------

;;;;;;;;;;;;;; Feature 3: Hyper Background ;;;;;;;;;;;;;;;
; --------------------------------------------------------
; Used vars for this feature: 2
; - var(7) *** Detects Hyper Combo Finish
; - var(8) *** Detects Normal Finish
; - root, var(34) *** Detect hyper projectiles or helpers (only parent)
[State -4, Hyper Combo Finish Varset]
type = VarSet
triggerall = var(7) = 0
triggerall = root, WinKO
triggerall = !NumHelper(1338000003)
trigger1 = root, var(34)
var(7) = 1

[State -4, Normal Finish Varset]
type = VarSet
triggerall = var(8) = 0
triggerall = var(7) = 0
trigger1 = root, WinKO
trigger1 = !(root, var(34))
var(8) = 1

[State -4, Hyper Background Helper]
type = Helper
triggerall = Root, MoveType != H
triggerall = !NumHelper(1338000001)
triggerall = !NumHelper(1338000003)
trigger1 = root, stateno = [3000, 4999]
name = "Hyper Background"
ID = 1338000001
stateno = 1338000001
pos = 0,0
postype = back
supermovetime = 9999999999
pausemovetime = 9999999999

[State -4, Hyper Combo Finish Helper]
type = Helper
triggerall = Root, MoveType != H
triggerall = !NumHelper(1338000003)
trigger1 = (var(7) = 1) && (!var(8))
name = "Hyper Combo Finish"
ID = 1338000003
stateno = 1338000003
pos = 0,0
postype = back
supermovetime = 9999999999
pausemovetime = 9999999999

[State -4, HCF Varset]
type = VarSet
triggerall = var(7) = 1
trigger1 = NumHelper(1338000003)
var(7) = -1

[State -4, Reset Vars]
type = VarSet
trigger1 = Roundstate = [0, 2]
var(7) := var(8) := 0
; --------------------------------------------------------

;;;;;;;;;;;;;;;; Feature 4: Player Simbols ;;;;;;;;;;;;;;;
; --------------------------------------------------------
; Used vars for this feature: 0
; Shows a simbol P1 (O) when foe is offscreen
[State -4, Simbol 1]
type = Explod
triggerall = (enemynear, Alive) && (roundstate = 2)
trigger1 = enemynear, ScreenPos Y < 0
trigger2 = enemynear, ScreenPos Y > 220 - (const(size.head.pos.y))
trigger3 = P2BodyDist Y > 200
anim = 32090 + (2*(enemy, ID > root, ID))
ID = 32090
pos = ceil(enemynear, screenpos x), 15 + (enemynear, screenpos y > 0) * 200
postype = left
ontop = 1
bindtime = -1
removetime = 1
scale = 0.5,0.5
pausemovetime = 500
supermovetime = 500

; Shows a simbol P1 (>) when foe is offscreen
[State -4, Simbol 2]
type = Explod
triggerall = (enemynear, Alive) && (roundstate = 2)
trigger1 = enemynear, ScreenPos Y < 0
trigger2 = enemynear, ScreenPos Y > 220 - (const(size.head.pos.y))
trigger3 = P2BodyDist Y > 200
anim = 32091 + (2*(enemy, ID > root, ID))
ID = 32091
pos = ceil(enemynear, screenpos x), 15 + (enemynear, screenpos y > 0) * 200
postype = left
ontop = 1
bindtime = -1
facing = (enemynear, facing)
removetime = 1
scale = 0.3,0.3
pausemovetime = 500
supermovetime = 500
; --------------------------------------------------------

;;;;;;;;;;; Feature 5: Detect Metal-Like People ;;;;;;;;;;
; --------------------------------------------------------
; Used Vars for this feature: 1
; - var(14) ** Detect Metal-Like enemyes.
; This also includes Non-Marvel/Capcom Characters as well.
[State -2, Who is made of metal here?]
type = VarSet
trigger1  = enemynear, name = "Sentinel"
trigger2  = enemynear, name = "Sentinel by ER"
trigger3  = enemynear, name = "Iron Man"
trigger4  = enemynear, name = "Iron-Man"
trigger5  = enemynear, name = "War Machine"
trigger6  = enemynear, name = "Marvel vs. Capcom's WarMachine"
trigger7  = enemynear, name = "Dr. Doom"
trigger8  = enemynear, name = "Doctor Doom"
trigger9  = enemynear, name = "Dr. Doom by WhiteMagic2002"
trigger10 = enemynear, name = "Dr.Doom"
trigger11 = enemynear, name = "Dr. Doom By {_Carnificina_}"
trigger12 = enemynear, name = "Tron Bonne"
trigger13 = enemynear, name = "Tron"
trigger14 = enemynear, name = "Abyss Form 1"
trigger15 = enemynear, name = "Chotto-Ko Mech-Gouki"
trigger16 = enemynear, name = "Mech Gouki"
trigger17 = enemynear, name = "Mazinger Z"
trigger18 = enemynear, name = "karakuri"
trigger19 = enemynear, name = "phobos"
trigger20 = enemynear, name = "Abyss-First type"
trigger21 = enemynear, name = "God Gundam"
trigger22 = enemynear, name = "ShinGetter1"
var(14) = 1 - (P2StateNo = 5150)

[State -2, Who isn't?]
type = VarSet
trigger1 = enemynear, name != "Sentinel"
trigger1 = enemynear, name != "Sentinel by ER"
trigger1 = enemynear, name != "Iron Man"
trigger1 = enemynear, name != "Iron-Man"
trigger1 = enemynear, name != "War Machine"
trigger1 = enemynear, name != "Marvel vs. Capcom's WarMachine"
trigger1 = enemynear, name != "Dr. Doom"
trigger1 = enemynear, name != "Doctor Doom"
trigger1 = enemynear, name != "Dr. Doom by WhiteMagic2002"
trigger1 = enemynear, name != "Dr.Doom"
trigger1 = enemynear, name != "Dr. Doom By {_Carnificina_}"
trigger1 = enemynear, name != "Tron Bonne"
trigger1 = enemynear, name != "Tron"
trigger1 = enemynear, name != "Abyss Form 1"
trigger1 = enemynear, name != "Chotto-Ko Mech-Gouki"
trigger1 = enemynear, name != "Mech Gouki"
trigger1 = enemynear, name != "Mazinger Z"
trigger1 = enemynear, name != "karakuri"
trigger1 = enemynear, name != "phobos"
trigger1 = enemynear, name != "Abyss-First type"
trigger1 = enemynear, name != "God Gundam"
trigger1 = enemynear, name != "ShinGetter1"
var(14) = 0
; --------------------------------------------------------

;;;;;;;;;;;;; Feature 6: Aerial Rave Prev Fix ;;;;;;;;;;;;
; --------------------------------------------------------
; Used Vars for this feature: 1
; - var(15) ** Detect Very big chars or Bosses that don't
;              allow aerial rave finishers.
[State -4, Special Cases for AR]
type = VarSet
trigger1  = p2name != "Apocalypse"
trigger2  = p4name != "Apocalypse"
trigger3  = p2name != "Onslaught"
trigger4  = p4name != "Onslaught"
trigger5  = P2name != "Abyss Form 1"
trigger6  = P4name != "Abyss Form 1"
trigger7  = P2name != "Abyss Form 2"
trigger8  = P4name != "Abyss Form 2"
trigger9  = P2name != "Abyss Form 3"
trigger10 = P4name != "Abyss Form 3"
trigger11 = P2name != "Abyss"
trigger12 = P4name != "Abyss"
var(15) = 1

[State -4, Special Cases for AR]
type = VarSet
trigger1  = p2name = "Apocalypse"
trigger2  = p4name = "Apocalypse"
trigger3  = p2name = "Onslaught"
trigger4  = p4name = "Onslaught"
trigger5  = P2name = "Abyss Form 1"
trigger6  = P4name = "Abyss Form 1"
trigger7  = P2name = "Abyss Form 2"
trigger8  = P4name = "Abyss Form 2"
trigger9  = P2name = "Abyss Form 3"
trigger10 = P4name = "Abyss Form 3"
trigger11 = P2name = "Abyss"
trigger12 = P4name = "Abyss"
var(15) = 0
; --------------------------------------------------------

[State MS - M, DisplayToClipboard]
type = DisplayToClipboard
trigger1 = 1
text = "F.Attack: %d, H.Count: %d, A.Rave: %d, Danger: %d, D.Holder: %d\n"
params = var(1), var(2), var(3), var(4), var(5)

[State MS - END] ;ctrl a tick ago
type = Null
trigger1 = var(0) := root, ctrl

; ========================================================================
;Main System Helper (Controls full game features, Non Tag Mode Template)
[StateDef 1337000001]
anim = 1337000000
ctrl = 0

[State MS - X, IX]
type = AssertSpecial
trigger1 = 1
flag = noshadow
flag2 = invisible

[State MS - Pos, 01]
type = BindToRoot
trigger1 = 1
facing = (root, facing)
pos = 0, 0

;;;;;;;;;;;;;;; Feature 1: Combo Messages ;;;;;;;;;;;;;;;;
; --------------------------------------------------------
; Original by Ryou Win - Used vars for this feature: 5
; - var(1) *** Special var for First Attack (avoids var reset if intro skipped)
; - var(2) *** Ground Hit Count
; - var(3) *** Aerial Hit Count (buggy)
; - var(4) *** Danger Var
; - var(5) *** PlaceHolder for Counter and Danger vars
[State -4, FA - Initial Value]
type = VarSet
trigger1 = (var(1) != 1) && (roundstate <= 2)
trigger2 = (var(1) = 1) && (roundstate < 2)
var(1) = -1

[State -4, FA - Active]
type = VarSet
trigger1 = (NumExplod(32100)) && (var(1) = -1)
var(1) = 0

[State -4, FA - Done]
type = VarSet
trigger1 = (var(1) = 0) && (roundstate >= 2)
trigger2 = (var(2) = -1) && (root, MoveType = H) && (root, Stateno != [150, 155])
var(1) = 1
;----------------------------

[State -4, HitCount PlaceHolder]
type = VarSet
trigger1 = var(2) >= 3
trigger2 = (var(2) = -1) && (P2MoveType = H) && (P2StateNo != [150, 155])
var(5) = 1 + (var(2) > 4) + (var(2) > 5) + (var(2) > 7) + (var(2) > 9) + (var(2) > 29) + (var(2) > 49) + (var(2) > 69) - (var(2) = -1)

[State -4, Aerial HitCount PlaceHolder]
type = VarSet
trigger1 = var(3) > 1
var(5) = 10

[State -4, Danger On]
type = VarSet
trigger1 = (var(4) != 1) && (roundstate = 2) && (root, life = [1, (root,LifeMax/4)])
var(9) = 1
;----------------------------

[State -4, FA - Danger Sound]
type = PlaySnd
triggerall = !NumExplod(32100)
trigger1 = (var(9)) && (var(4) = 0) && (root, life > 0)
trigger2 = (var(2) = -1) && (P2MoveType = H) && (P2StateNo != [150, 155])
value = 32100, Cond(var(9), 9, 0)
volumescale = 100

[State -4, Combo Sounds]
type = PlaySnd
trigger1 = (!NumExplod(32100)) && (var(2) = 0 && var(3) = 0 && var(5) != 0)
value = 32100, Cond(var(5) > 9, 30, Cond(var(9), 9, var(5)))
volumescale = 100

[State -4, Combo Message (left)]
type = Explod
triggerall = TeamSide = 1 && !NumExplod(32100)
trigger1 = var(2) = 0 && var(3) = 0 && var(5) != 0
trigger2 = (var(2) = -1) && (P2MoveType = H) && (P2StateNo != [150, 155])
trigger3 = (var(9)) && (var(4) = 0) && (root, life > 0)
anim = 32100 + Cond(var(5) > 9, 30, Cond(var(9), 9, var(5)))
ID = 32100
postype = left
pos = 0, 80
ontop = 1
bindtime = -1
removetime = 60
supermovetime = 60
pausemovetime = 60
scale = 0.5,0.5

[State -4, Combo Message (right)]
type = Explod
triggerall = TeamSide = 2 && !NumExplod(32100)
trigger1 = var(2) = 0 && var(3) = 0 && var(5) != 0
trigger2 = (var(2) = -1) && (P2MoveType = H) && (P2StateNo != [150, 155])
trigger3 = (var(9)) && (var(4) = 0) && (root, life > 0)
anim = 32110 + Cond(var(5) > 9, 21, Cond(var(9), 9, var(5)))
ID = 32100
postype = right
pos = -1, 80
ontop = 1
bindtime = -1
removetime = 60
supermovetime = 60
pausemovetime = 60
scale = 0.5,0.5
;----------------------------

[State -4, Main HitCount]
type = VarAdd
trigger1 = (enemynear, time = 1) && (enemynear, HitShakeOver = 0) && (P2MoveType = H) && (P2StateNo != [150, 155])
var(2) = 1 + (var(2) = -1)

[State -4, Main HitCount (Aerial Rave)]
type = VarAdd
triggerall = Root, HitDefAttr = A, NA, SA, HA
trigger1 = (enemynear, time = 1) && (enemynear, HitShakeOver = 0) && (P2MoveType = H) && (P2StateNo != [150, 155]) && (P2StateType = A)
var(3) = 1

[State -4, Reset HitCount]
type = VarSet
trigger1 = var(2) != -1 && (p2movetype != H || enemynear, ctrl)
trigger2 = (var(2) = -1) && (root, MoveType = H) && (root, Stateno != [150, 155])
trigger3 = (var(2) = -1) && (P2MoveType = H) && (P2StateNo != [150, 155])
var(2) = 0 - (var(1) = -1)

[State -4, Reset HitCount (Aerial Rave)]
type = VarSet
trigger1 = var(2) != -1 && (p2movetype != H || enemynear, ctrl)
trigger2 = Root, HitDefAttr = SC, NA, SA, HA
trigger2 = (P2MoveType = H) && (P2StateNo != [150, 155])
var(3) = 0

[State -4, Reset PlaceHolder Var]
type = VarSet
triggerall = NumExplod(32100)
trigger1 = (var(2) = 0) || (var(3) = 0) || (roundstate != 2)
var(5) = 0

[State -4, Reset PlaceHolder Var]
type = VarSet
trigger1 = NumExplod(32100) || (root, life > (root, LifeMax/4))
var(9) = 0

[State -4, Danger Indicator]
type = VarSet
trigger1 = var(4) = 1 && roundstate != 2
trigger2 = var(4) = 0 && root, life <= (root,LifeMax/4)
var(4) = (roundstate > 1)

[State -4, Danger Indicator]
type = VarSet
trigger1 = var(4) && Roundstate > 1 && (root,life > (root,LifeMax/4))
var(4) = 0
; --------------------------------------------------------

;;;;;;;;;;;;;; Feature 2: Hyper Background ;;;;;;;;;;;;;;;
; --------------------------------------------------------
; Used vars for this feature: 2
; - var(7) *** Detects Hyper Combo Finish
; - var(8) *** Detects Normal Finish
; - root, var(34) *** Detect hyper projectiles or helpers (only parent)
[State -4, Hyper Combo Finish Varset]
type = VarSet
triggerall = var(7) = 0
triggerall = root, WinKO
triggerall = !NumHelper(1338000003)
trigger1 = root, var(34)
var(7) = 1

[State -4, Normal Finish Varset]
type = VarSet
triggerall = var(8) = 0
triggerall = var(7) = 0
trigger1 = root, WinKO
trigger1 = !(root, var(34))
var(8) = 1

[State -4, Hyper Background Helper]
type = Helper
triggerall = Root, MoveType != H
triggerall = !NumHelper(1338000001)
triggerall = !NumHelper(1338000003)
trigger1 = root, stateno = [3000, 4999]
name = "Hyper Background"
ID = 1338000001
stateno = 1338000001
pos = 0,0
postype = back
supermovetime = 9999999999
pausemovetime = 9999999999

[State -4, Hyper Combo Finish Helper]
type = Helper
triggerall = Root, MoveType != H
triggerall = !NumHelper(1338000003)
trigger1 = (var(7) = 1) && (!var(8))
name = "Hyper Combo Finish"
ID = 1338000003
stateno = 1338000003
pos = 0,0
postype = back
supermovetime = 9999999999
pausemovetime = 9999999999

[State -4, HCF Varset]
type = VarSet
triggerall = var(7) = 1
trigger1 = NumHelper(1338000003)
var(7) = -1

[State -4, Reset Vars]
type = VarSet
trigger1 = Roundstate = [0, 2]
var(7) := var(8) := 0
; --------------------------------------------------------

;;;;;;;;;;;;;;;; Feature 3: Player Simbols ;;;;;;;;;;;;;;;
; --------------------------------------------------------
; Used vars for this feature: 0
; Shows a simbol P1 (O) when foe is offscreen
[State -4, Simbol 1]
type = Explod
triggerall = (enemynear, Alive) && (roundstate = 2)
trigger1 = enemynear, ScreenPos Y < 0
trigger2 = enemynear, ScreenPos Y > 220 - (const(size.head.pos.y))
trigger3 = P2BodyDist Y > 200
anim = 32090 + (2*(enemy, ID > root, ID))
ID = 32090
pos = ceil(enemynear, screenpos x), 15 + (enemynear, screenpos y > 0) * 200
postype = left
ontop = 1
bindtime = -1
removetime = 1
scale = 0.5,0.5
pausemovetime = 500
supermovetime = 500

; Shows a simbol P1 (>) when foe is offscreen
[State -4, Simbol 2]
type = Explod
triggerall = (enemynear, Alive) && (roundstate = 2)
trigger1 = enemynear, ScreenPos Y < 0
trigger2 = enemynear, ScreenPos Y > 220 - (const(size.head.pos.y))
trigger3 = P2BodyDist Y > 200
anim = 32091 + (2*(enemy, ID > root, ID))
ID = 32091
pos = ceil(enemynear, screenpos x), 15 + (enemynear, screenpos y > 0) * 200
postype = left
ontop = 1
bindtime = -1
facing = (enemynear, facing)
removetime = 1
scale = 0.3,0.3
pausemovetime = 500
supermovetime = 500
; --------------------------------------------------------

;;;;;;;;;;; Feature 4: Detect Metal-Like People ;;;;;;;;;;
; --------------------------------------------------------
; Used Vars for this feature: 1
; - var(14) ** Detect Metal-Like enemyes.
; This also includes Non-Marvel/Capcom Characters as well.
[State -2, Who is made of metal here?]
type = VarSet
trigger1  = enemynear, name = "Sentinel"
trigger2  = enemynear, name = "Sentinel by ER"
trigger3  = enemynear, name = "Iron Man"
trigger4  = enemynear, name = "Iron-Man"
trigger5  = enemynear, name = "War Machine"
trigger6  = enemynear, name = "Marvel vs. Capcom's WarMachine"
trigger7  = enemynear, name = "Dr. Doom"
trigger8  = enemynear, name = "Doctor Doom"
trigger9  = enemynear, name = "Dr. Doom by WhiteMagic2002"
trigger10 = enemynear, name = "Dr.Doom"
trigger11 = enemynear, name = "Dr. Doom By {_Carnificina_}"
trigger12 = enemynear, name = "Tron Bonne"
trigger13 = enemynear, name = "Tron"
trigger14 = enemynear, name = "Abyss Form 1"
trigger15 = enemynear, name = "Chotto-Ko Mech-Gouki"
trigger16 = enemynear, name = "Mech Gouki"
trigger17 = enemynear, name = "Mazinger Z"
trigger18 = enemynear, name = "karakuri"
trigger19 = enemynear, name = "phobos"
trigger20 = enemynear, name = "Abyss-First type"
trigger21 = enemynear, name = "God Gundam"
trigger22 = enemynear, name = "ShinGetter1"
var(14) = 1 - (P2StateNo = 5150)

[State -2, Who isn't?]
type = VarSet
trigger1 = enemynear, name != "Sentinel"
trigger1 = enemynear, name != "Sentinel by ER"
trigger1 = enemynear, name != "Iron Man"
trigger1 = enemynear, name != "Iron-Man"
trigger1 = enemynear, name != "War Machine"
trigger1 = enemynear, name != "Marvel vs. Capcom's WarMachine"
trigger1 = enemynear, name != "Dr. Doom"
trigger1 = enemynear, name != "Doctor Doom"
trigger1 = enemynear, name != "Dr. Doom by WhiteMagic2002"
trigger1 = enemynear, name != "Dr.Doom"
trigger1 = enemynear, name != "Dr. Doom By {_Carnificina_}"
trigger1 = enemynear, name != "Tron Bonne"
trigger1 = enemynear, name != "Tron"
trigger1 = enemynear, name != "Abyss Form 1"
trigger1 = enemynear, name != "Chotto-Ko Mech-Gouki"
trigger1 = enemynear, name != "Mech Gouki"
trigger1 = enemynear, name != "Mazinger Z"
trigger1 = enemynear, name != "karakuri"
trigger1 = enemynear, name != "phobos"
trigger1 = enemynear, name != "Abyss-First type"
trigger1 = enemynear, name != "God Gundam"
trigger1 = enemynear, name != "ShinGetter1"
var(14) = 0
; --------------------------------------------------------

;;;;;;;;;;;;; Feature 5: Aerial Rave Prev Fix ;;;;;;;;;;;;
; --------------------------------------------------------
; Used Vars for this feature: 1
; - var(15) ** Detect Very big chars or Bosses that don't
;              allow aerial rave finishers.
[State -4, Special Cases for AR]
type = VarSet
trigger1  = p2name != "Apocalypse"
trigger2  = p4name != "Apocalypse"
trigger3  = p2name != "Onslaught"
trigger4  = p4name != "Onslaught"
trigger5  = P2name != "Abyss Form 1"
trigger6  = P4name != "Abyss Form 1"
trigger7  = P2name != "Abyss Form 2"
trigger8  = P4name != "Abyss Form 2"
trigger9  = P2name != "Abyss Form 3"
trigger10 = P4name != "Abyss Form 3"
trigger11 = P2name != "Abyss"
trigger12 = P4name != "Abyss"
var(15) = 1

[State -4, Special Cases for AR]
type = VarSet
trigger1  = p2name = "Apocalypse"
trigger2  = p4name = "Apocalypse"
trigger3  = p2name = "Onslaught"
trigger4  = p4name = "Onslaught"
trigger5  = P2name = "Abyss Form 1"
trigger6  = P4name = "Abyss Form 1"
trigger7  = P2name = "Abyss Form 2"
trigger8  = P4name = "Abyss Form 2"
trigger9  = P2name = "Abyss Form 3"
trigger10 = P4name = "Abyss Form 3"
trigger11 = P2name = "Abyss"
trigger12 = P4name = "Abyss"
var(15) = 0
; --------------------------------------------------------

[State MS - M, DisplayToClipboard]
type = DisplayToClipboard
trigger1 = 1
text = "F.Attack: %d, H.Count: %d, A.Rave: %d, Danger: %d, D.Holder: %d\n"
params = var(1), var(2), var(3), var(4), var(5)

[State MS - END] ;ctrl a tick ago
type = Null
trigger1 = var(0) := root, ctrl

; ========================================================================
; Feature Helpers:
; This sections contains the helpers that are called back in the main
; system helper, most are self-explanatory
; ========================================================================

; ========================================================================
;K.O. Helper (for simul mode)
[StateDef 1338000000]
anim = 1337000000
ctrl = 0

[State FX, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow
flag2 = invisible
flag3 = nokoslow

[State FX-0, EnvColor]
type = EnvColor
trigger1 = time < 10
trigger1 = time % 2
value = 255,255,255
time = 1

[State FX-1, PlaySnd]
type = PlaySnd
trigger1 = time = 0
value = 32080, 0
volumescale = 100

[State FX-4b, Pause]
type = Pause
trigger1 = (time % 1) = 0
time = 1

[State FX-4, Exit]
type = DestroySelf
trigger1 = time >= 60


; ========================================================================
; Hyper Background Effects
[Statedef 1338000001]
anim = 1337000000
ctrl = 0

[State HBG, AssertSpecial]
type = AssertSpecial
trigger1 = 1
flag = noshadow
flag2 = invisible

; Thanks to _nabeshin_ for the Hyper BG Sprites.
[State HBG, DHC]
type = AssertSpecial
trigger1 = Time < 60
flag = noBG
flag2 = noFG

;Hyper BG (Color may change if HC var is active)
;-----------------------------------------------
[State HBG, HBG]
type = Explod
triggerall = !NumExplod(32060)
trigger1 = Time >= 60
anim = 32060
ID = 32060
pos = 0, 0
postype = Back
sprpriority = -5
supermovetime = 500
pausemovetime = 500
removetime = -1
bindtime = -1
ownpal = 1

; Remove Effects
; --------------------------------------
[State HBG, Remove Hyper BG (right)]
type = RemoveExplod
trigger1 = root, stateno != [3000,4999]
trigger2 = NumHelper(1338000003)    ; Hyper Combo Finish is active
trigger3 = Root, MoveType = H          ; If by any chance you are in a custom state...
ID = 32060

[State HBG, DestroySelf]
type = DestroySelf
trigger1 = root, stateno != [3000,4999]
trigger2 = NumHelper(1338000003)    ; Hyper Combo Finish is active
trigger3 = Root, MoveType = H          ; If by any chance you are in a custom state...


; ========================================================================
; Hyper Combo Finish Helper
[Statedef 1338000003]
anim = 1337000000
ctrl = 0

[State HCF, AS - 1]
type = AssertSpecial
trigger1 = 1
flag = noshadow
flag2 = invisible

; Thanks to Erradicator for the Hyper Combo Finish BG!!!
[State HCF, 1 as_EX]
type = AssertSpecial
trigger1 = 1
flag = NoBG
flag2 = NoBarDisplay
flag3 = NoFG

[State HCF, 2 as_EX]
type = PlaySnd
trigger1 = time = 0
value = 32080, 1
volumescale = 100
persistent = 0
channel = 4

; Hyper Combo Finish BG (thanks to Erradicator)
[State HCF, 3 as_EX]
type = Explod
trigger1 = time = 0
ID = 32080
anim = 32080
postype = back
pos = 0, 0
bindtime = -1
removetime = -2
sprpriority = -5
persistent = 0
ownpal = 1
supermovetime = 500
pausemovetime = 500

[State HCF, DestroySelf]
type = DestroySelf
trigger1 = !NumExplod(32080) && time > 0
